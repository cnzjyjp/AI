#include<stdio.h>

int solution[9][9];//结果
int solution1[9][9];//i行j列已解决时值为1
int row[9][9];//行i数字为j时值为1
int column[9][9];//列i数字为j时值为1
int grids[9][9];//粗线宫i数字为j时值为1
int x[2][9];//对角线i数字为j时值为1
int total;//遍历的节点数
int flag;//结束标志

int Find_Value(int i, int j, int value){
    int k, value1 = -1;
    for(k = value; k < 9; k++){
        if((row[i][k] == 0) && (column[j][k] == 0) && (grids[(i/3)*3+j/3][k] == 0) && ((i != j) || (x[0][k] == 0)) && ((i+j != 8) || (x[1][k] == 0))){
            value1 = k;
            break;
        }
    }
    return value1;
}

void Backtracking_Search(){
    int i, j, k, grid = 81;
    for(k = 0; k < 81; k++){//选择下一个未解决的格子
        i = k/9;
        j = k-(i*9);
        if(solution1[i][j] == 0){
            grid = k;
            break;
        }
    }
    if(grid == 81){//完成
        flag = 1;
        return;
    }
    else{//继续求解
        i = grid/9;
        j = grid-(i*9);
        while((solution[i][j] = Find_Value(i, j, solution[i][j]+1)) !=-1){
            total++;
            solution1[i][j] = 1;
            row[i][solution[i][j]] = 1;
            column[j][solution[i][j]] = 1;
            grids[(i/3)*3+j/3][solution[i][j]] = 1;
            if(i == j){
                x[0][solution[i][j]] = 1;
            }
            if(i + j == 8){
                x[1][solution[i][j]] = 1;
            }
            Backtracking_Search();
            if(flag == 1){
                break;
            }
            solution1[i][j] = 0;
            row[i][solution[i][j]] = 0;
            column[j][solution[i][j]] = 0;
            grids[(i/3)*3+j/3][solution[i][j]] = 0;
            if(i == j){
                x[0][solution[i][j]] = 0;
            }
            if(i + j == 8){
                x[1][solution[i][j]] = 0;
            }
        }
    }
}

int main(){
    int i, j;
    char inputname[25] = "../input/sudoku03.txt";
    char outputname[25] = "../output/sudoku03.txt";
    FILE *fp1, *fp2;
    fp1 = fopen(inputname, "r");
    if(!fp1){
        printf("No such file!\n");
        return 0;
    }
    fp2 = fopen(outputname, "w");
    if(!fp2){
        printf("Can't create the file!\n");
        return 0;
    }
    for(i = 0; i < 9; i++){
        for(j = 0; j < 9; j++){
            solution1[i][j] = 0;
            row[i][j] = 0;
            column[i][j] = 0;
            grids[i][j] = 0;
        }
    }
    for(i = 0; i < 9; i++){
        x[0][i] = 0;
        x[1][i] = 0;
    }
    for(i = 0; i < 9; i++){//读文件设置初始状态
        for(j = 0; j < 9; j++){
            fscanf(fp1, "%d", &solution[i][j]);
            solution[i][j]--;//为了数组表示方便，全部转化为0-8，故最后的结果需要全部加1
            if(solution[i][j] != -1){
                solution1[i][j] = 1;
                row[i][solution[i][j]] = 1;
                column[j][solution[i][j]] = 1;
                grids[(i/3)*3+j/3][solution[i][j]] = 1;
                if(i == j){
                    x[0][solution[i][j]] = 1;
                }
                if(i + j == 8){
                    x[1][solution[i][j]] = 1;
                }
            }
        }
    }
    total = 0;
    flag = 0;
    Backtracking_Search();
    if(flag == 0){
        printf("No solution!\n");
        fclose(fp1);
        fclose(fp2);
        return 0;
    }
    for(i = 0; i < 9; i++){
        for(j = 0; j < 9; j++){
            if(j == 8){
                fprintf(fp2, "%d\n", solution[i][j]+1);
            }
            else{
                fprintf(fp2, "%d ", solution[i][j]+1);
            }
        }
    }
    printf("%d\n", total+1);
    fclose(fp1);
    fclose(fp2);
    return 0;
}
