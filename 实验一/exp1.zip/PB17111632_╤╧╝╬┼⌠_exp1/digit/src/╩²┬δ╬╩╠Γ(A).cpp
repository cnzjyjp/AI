#include <stdio.h>
#include <cmath>
#include <queue>
#include <set>
#include <string>

#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3

using namespace std;

FILE *fp2;
typedef int DigitTable[5][5];
const char* direct[4] = {"up", "down", "left", "right"};
typedef struct Node{
    int evaluation=0; // 评估函数
    int heu=0;
    int cost=0; // 耗散值
    queue<int> steps; // 格式：8,0,13,1 == (8,up),(13,down);
    DigitTable digitalTable={{0}};
    int blank[2]={0}; // 无滑块的位置
}Node;


// 为了方便计算启发函数，设置下表
// index 是是滑块的编号，值是位置（从0到24）
int resultPos[22] = {0,
                     0, 1, 2, 3, 4,
                     10, 6, 7, 8, 9,
                     12, 13, 14, 15, 16,
                     17, 18, 19, 20, 21,
                     22};
// 每个数字的权重，权重矩阵是多次实验调整得到的，当然几乎不可能是最优解
int weight_array[22] = {0,
                        2, 1, 1, 1, 2,
                        4, 5, 1, 1, 1,
                        1, 1, 1, 1, 1,
                        1, 1, 1, 1, 1,
                        1};
struct cmp {
    // 比较函数, 用于优先队列
    bool operator()(Node *a, Node *b) {
        if (a->evaluation > b->evaluation) return true;
        if (a->evaluation == b->evaluation) return a->cost > b->cost;
        return false;  //与greater是等价的
        // return a->f > b->f;
    }
};
priority_queue<Node*, vector<Node*>, cmp> fringe; // 边缘队列
Node root;
set<string> visited;

int Heuristic(DigitTable);
void input(const char *filename);
void ExpandNode(Node* pNode0);
void AStar();
void PrintPath(Node* node);
string ArrToString(DigitTable);


int main(){
    // 初始化根节点
    input("../input/1.txt");
    fp2=fopen("../output/A/1.txt","w");
    if(fp2==NULL){
        printf("Can't create the file!!!");
    }

/*    for(int i=0;i<5; i++){
        for(int j=0;j<5; j++)
            printf(" %d ", root.digitalTable[i][j]);
        printf("\n");
    } 
    printf("%d\n", root.evaluation);
    printf("%d %d\n", root.blank[0], root.blank[1]);*/ 
    AStar();
    fclose(fp2);
    return 0;
}

string ArrToString(DigitTable arr){
    string result = "";
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            result += to_string(arr[i][j]);
        }
    }
    return result;
}


void AStar(){
    Node* minNode;
    int i=0;
    while(true){
        minNode = fringe.top();
        fringe.pop();
		/* printf("%d %d %d %d \n", i, fringe.size(), minNode->evaluation, minNode->cost);
            for(int j=0;j<5; j++){
                for(int k=0;k<5; k++)
                    printf(" %d ", minNode->digitalTable[j][k]);
                printf("\n");
            }*/ 
        i++;
        if(minNode->heu==0){
            PrintPath(minNode);
            break;
        }
        ExpandNode(minNode);
//        delete minNode;
    }
}

void PrintPath(Node* node){
    Node* rootNode = &root;
    int i = 0;
    int num, dir;
    while(!node->steps.empty()){
        i++;
        num = node->steps.front();
        node->steps.pop();
        dir = node->steps.front();
        node->steps.pop();
        fprintf(fp2, "(%d,%s);", num, direct[dir]);
    }
    printf("%d",i);
}

void ExpandNode(Node* pNode0){
    int digit, tmp;
    int x0, y0, x1, y1;
    Node* pNode1;
    int pos0 = pNode0->blank[0];
    int pos1 = pNode0->blank[1];
    if(pos0 > pos1){ // 位次号小的作为空格0
        tmp = pos0;
        pos0 = pos1;
        pos1 = tmp;
    }
    x0 = pos0/5;
    y0 = pos0%5;
    x1 = pos1/5;
    y1 = pos1%5;
    if(x0 != 0){ // 空格0上边有滑块
        digit = pNode0->digitalTable[x0-1][y0];
        if(digit != 0 && digit != 7){
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->blank[0] = pos0 - 5;
            pNode1->blank[1] = pos1;
            pNode1->digitalTable[x0][y0] = digit;
            pNode1->digitalTable[x0-1][y0] = 0;
            pNode1->steps.push(digit);
            pNode1->steps.push(DOWN);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    }
    if(x0 != 4){ // 空格0下边有滑块
        digit = pNode0->digitalTable[x0+1][y0];
        if(digit != 0 && digit != 7){
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->blank[0] = pos0 + 5;
            pNode1->blank[1] = pos1;
            pNode1->digitalTable[x0][y0] = digit;
            pNode1->digitalTable[x0+1][y0] = 0;
            pNode1->steps.push(digit);
            pNode1->steps.push(UP);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    }
    if(y0 != 0){ // 空格0左边有滑块
        digit = pNode0->digitalTable[x0][y0-1];
        if(digit != 0 && digit != 7){
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->blank[0] = pos0 -  1;
            pNode1->blank[1] = pos1;
            pNode1->digitalTable[x0][y0] = digit;
            pNode1->digitalTable[x0][y0-1] = 0;
            pNode1->steps.push(digit);
            pNode1->steps.push(RIGHT);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    }
    if(y0 != 4){ // 空格0右边有滑块
        digit = pNode0->digitalTable[x0][y0+1];
        if(digit != 0 && digit != 7){
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->blank[0] = pos0 + 1;
            pNode1->blank[1] = pos1;
            pNode1->digitalTable[x0][y0] = digit;
            pNode1->digitalTable[x0][y0+1] = 0;
            pNode1->steps.push(digit);
            pNode1->steps.push(LEFT);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    }
    if(x1 != 0){ // 空格1上边有滑块
        digit = pNode0->digitalTable[x1-1][y1];
        if(digit != 0 && digit != 7){
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->blank[0] = pos0;
            pNode1->blank[1] = pos1 - 5;
            pNode1->digitalTable[x1][y1] = digit;
            pNode1->digitalTable[x1-1][y1] = 0;
            pNode1->steps.push(digit);
            pNode1->steps.push(DOWN);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    }
    if(x1 != 4){ // 空格1下边有滑块
        digit = pNode0->digitalTable[x1+1][y1];
        if(digit != 0 && digit != 7){
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->blank[0] = pos0;
            pNode1->blank[1] = pos1 + 5;
            pNode1->digitalTable[x1][y1] = digit;
            pNode1->digitalTable[x1+1][y1] = 0;
            pNode1->steps.push(digit);
            pNode1->steps.push(UP);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    }
    if(y1 != 0){ // 空格1左边有滑块
        digit = pNode0->digitalTable[x1][y1-1];
        if(digit != 0 && digit != 7){
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->blank[0] = pos0;
            pNode1->blank[1] = pos1 - 1;
            pNode1->digitalTable[x1][y1] = digit;
            pNode1->digitalTable[x1][y1-1] = 0;
            pNode1->steps.push(digit);
            pNode1->steps.push(RIGHT);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    }
    if(y1 != 4){ // 空格1右边有滑块
        digit = pNode0->digitalTable[x1][y1+1];
        if(digit != 0 && digit != 7){
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->blank[0] = pos0;
            pNode1->blank[1] = pos1 + 1;
            pNode1->digitalTable[x1][y1] = digit;
            pNode1->digitalTable[x1][y1+1] = 0;
            pNode1->steps.push(digit);
            pNode1->steps.push(LEFT);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    }
    // 滑块7的移动单独判断
    if(x0 == x1 && y1-y0 == 1 && x0 != 4)
        if(pNode0->digitalTable[x0+1][y0] == 7 && pNode0->digitalTable[x1+1][y1] == 7){ // 滑块7上移
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->digitalTable[x0][y0] = 7;
            pNode1->digitalTable[x1][y1] = 7;
            pNode1->digitalTable[x1+1][y1] = 7;
            pNode1->digitalTable[x0+1][y0] = 0;
            pNode1->digitalTable[x1+2][y1] = 0;
            pNode1->blank[0] = pos0 + 5;
            pNode1->blank[1] = pos1 + 10;
            pNode1->steps.push(7);
            pNode1->steps.push(UP);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    if(x1-x0 == 1 && y1-y0 == 1 && x0 != 0)
        if(pNode0->digitalTable[x0-1][y0] == 7 && pNode0->digitalTable[x1-1][y1] == 7){ // 滑块7下移
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->digitalTable[x0][y0] = 7;
            pNode1->digitalTable[x1][y1] = 7;
            pNode1->digitalTable[x1-1][y1] = 7;
            pNode1->digitalTable[x0-1][y0] = 0;
            pNode1->digitalTable[x1-2][y1] = 0;
            pNode1->blank[0] = pos0 - 5;
            pNode1->blank[1] = pos1 - 10;
            pNode1->steps.push(7);
            pNode1->steps.push(DOWN);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    if(x1-x0 == 1 && y1-y0 == 1 && y1 != 4)
        if(pNode0->digitalTable[x0][y0+1] == 7 && pNode0->digitalTable[x1][y1+1] == 7){ // 滑块7左移
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->digitalTable[x0][y0] = 7;
            pNode1->digitalTable[x1][y1] = 7;
            pNode1->digitalTable[x0][y0+1] = 7;
            pNode1->digitalTable[x0][y0+2] = 0;
            pNode1->digitalTable[x1][y1+1] = 0;
            pNode1->blank[0] = pos0 + 2;
            pNode1->blank[1] = pos1 + 1;
            pNode1->steps.push(7);
            pNode1->steps.push(LEFT);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
    if(y0 == y1 && x1-x0 == 1 && y0 != 0)
        if(pNode0->digitalTable[x0][y0-1] == 7 && pNode0->digitalTable[x1][y1-1] == 7){ // 滑块7右移
            pNode1 = new Node;
            *pNode1 = *pNode0;
            pNode1->digitalTable[x0][y0] = 7;
            pNode1->digitalTable[x1][y1] = 7;
            pNode1->digitalTable[x0][y0-1] = 7;
            pNode1->digitalTable[x0][y0-2] = 0;
            pNode1->digitalTable[x1][y1-1] = 0;
            pNode1->blank[0] = pos0 - 2;
            pNode1->blank[1] = pos1 - 1;
            pNode1->steps.push(digit);
            pNode1->steps.push(RIGHT);
            pNode1->cost += 1;
            pNode1->heu = Heuristic(pNode1->digitalTable);
            pNode1->evaluation = pNode1->heu + pNode1->cost;
            string str = ArrToString(pNode1->digitalTable);
            if(visited.count(str) == 0){
                visited.insert(str);
                fringe.push(pNode1);
            }
        }
}

int Heuristic(DigitTable arr){
    int h=0;
    int num, numOld, pos;
    int weight;
    for(int i=0; i<5; i++)
        for(int j=0; j<5; j++){
            num = arr[i][j];
            weight = weight_array[num];
            if(num != 0 && num != 7){
                pos = resultPos[num];
                h += weight*(abs(pos/5 - i) + abs(pos%5 - j));
            } else if(numOld == 7 && num == 7){
                h += weight*(abs(1-i) + abs(1-j));
            }
            numOld = num;
        }
    return h;
}

void input(const char* filename){

    FILE *fp=fopen(filename,"r");
    if(fp==NULL){
        printf("No such file!");
    }
    int t[5];
    int order = 0;
    for(int i=0; i<5; i++){
        fscanf(fp, "%d,%d,%d,%d,%d", &t[0], &t[1], &t[2], &t[3], &t[4]);
        for(int j=0; j<5; j++){
            root.digitalTable[i][j] = t[j];
            if(t[j] == 0)
                root.blank[order++] = i*5 + j;
        }
    }
    root.heu = Heuristic(root.digitalTable);
    root.evaluation =root.heu + root.cost;
    root.cost = 0;
    fringe.push(&root);
    visited.insert(ArrToString(root.digitalTable));
    fclose(fp);
}

